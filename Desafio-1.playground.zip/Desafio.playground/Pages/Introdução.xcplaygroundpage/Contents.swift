/*:
## Escola em Apuros!

 Parabéns! Você é a mais nova pessoa contratada pela prefeitura da cidade de Cornville 🎉.
 
 O seu objetivo é desenvolver um sistema que gerencie as escolas municipais!
 
 Porém, antes que você comece a desenvolver o sistema, a prefeitura achou que seria de bom tom pedir que você faça um treinamento antes.
 
 Quando se sentir pronto para começar, vá para a próxima página.
 
Página 1 de 5  |  [Na sequência: Salários](@next)
 */
